'use strict';
(() => {
 const root=document.querySelector('.home-studio');if(!root)return;
 const calm=matchMedia('(prefers-reduced-motion: reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)');
 // The service preview follows deliberate pointer or keyboard exploration.
 const rows=[...root.querySelectorAll('[data-service-preview]')],frames=[...root.querySelectorAll('[data-preview-frame]')];
 function selectService(index){rows.forEach(row=>row.classList.toggle('is-active',row.dataset.servicePreview===index));frames.forEach(frame=>frame.classList.toggle('is-active',frame.dataset.previewFrame===index))}
 rows.forEach(row=>{row.addEventListener('pointerenter',e=>{if(e.pointerType!=='touch')selectService(row.dataset.servicePreview)});row.addEventListener('focus',()=>selectService(row.dataset.servicePreview))});
 // A small local response to the pointer, with no document-wide animation loop.
 root.querySelectorAll('[data-room-card]').forEach(card=>{
  let frame=0,point=null;
  const reset=()=>{cancelAnimationFrame(frame);frame=0;point=null;['--cursor-x','--cursor-y','--photo-x','--photo-y'].forEach(name=>card.style.removeProperty(name))};
  card.addEventListener('pointermove',event=>{
   if(calm.matches||!fine.matches||event.pointerType==='touch')return;
   const bounds=card.getBoundingClientRect();point={x:(event.clientX-bounds.left)/bounds.width-.5,y:(event.clientY-bounds.top)/bounds.height-.5};
   if(frame)return;frame=requestAnimationFrame(()=>{if(point){card.style.setProperty('--cursor-x',`${point.x*16}px`);card.style.setProperty('--cursor-y',`${point.y*12}px`);card.style.setProperty('--photo-x',`${point.x*-7}px`);card.style.setProperty('--photo-y',`${point.y*-5}px`)}frame=0});
  });card.addEventListener('pointerleave',reset);card.addEventListener('blur',reset);calm.addEventListener('change',reset);
 });
})();
