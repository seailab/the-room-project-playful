'use strict';
(() => {
 // A real button makes the much-loved door reveal usable on touch and keyboard.
 document.querySelectorAll('.door-toggle-v6').forEach(button => {
  button.addEventListener('click', () => {
   const open=button.getAttribute('aria-pressed')!=='true';
   button.setAttribute('aria-pressed',String(open));
   button.closest('.birthday-art').classList.toggle('is-door-open',open);
   button.querySelector('span').textContent=open?button.dataset.doorCloseLabel:button.dataset.doorOpenLabel;
  });
 });
})();
