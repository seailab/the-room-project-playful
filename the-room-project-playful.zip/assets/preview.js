"use strict";
document.addEventListener("submit", event => {
 const form=event.target;
 if(!form.matches("[data-preview-enquiry]"))return;
 // Keep the interactive steps; intercept only the final submission.
 const submit=form.querySelector(".inquiry-submit");
 if(submit?.hidden)return;
 event.preventDefault();event.stopImmediatePropagation();
 const output=form.querySelector(".form-feedback,.inquiry-feedback");
 output.textContent="This is a design preview. No enquiry was sent or saved. Please share feedback with the person who sent you this link.";
 output.classList.remove("error");
},true);
