# The Room Project

Approved website design for client review, published with GitHub Pages.

Includes Home, About, Projects, Services, Journal, Contact, original room concepts, photographs, films and interactive artwork.

This review edition does not run a PHP backend or save enquiries. The complete private CMS is supplied separately for PHP/cPanel hosting.
